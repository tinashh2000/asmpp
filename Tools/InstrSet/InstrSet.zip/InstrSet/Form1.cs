﻿using Crc;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InstrSet
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            string cpuFile = "C:\\a16\\CPU16.RAW";

            StreamWriter writer = new StreamWriter("C:\\a16\\CPU16.csv");
            StreamReader reader = new StreamReader(cpuFile);

            List<string> keywords = new List<string>();
            List<KeywordDescription> description = new List<KeywordDescription>();

            POSITIONS pos = POSITIONS.UNDEFINED;
            while (!reader.EndOfStream)
            {
                string ln = reader.ReadLine().Trim();
                string comment = "";
                int commentPos = ln.IndexOf(";");
                if (commentPos != -1)
                {
                    comment = ln.Substring(commentPos + 1);
                    ln = ln.Substring(0, commentPos);   //remove comments                    
                }

                if (ln == "")
                    continue;
                if (ln.Length >= 4 && ln.Trim().Substring(0, 4).ToLower() == "even") //Ignore where we put the EVEN statement
                    continue;
                else if (ln.Length >= 3 && ln.Substring(0, 3).ToLower() == "db " && ln.Substring(3).Trim() == "0") //If we have DB followed by 0
                    continue;
                else if (ln.Length >= 3 && ln.Substring(0, 3).ToLower() == "db " && ln.Substring(3).Trim().Substring(0, 1) == "\"") //If we have DB followed by a quote
                {
                    string keyw = ln.Substring(3).Trim().Replace("\"", "");
                    keywords.Add(keyw);
                }
                else if (ln.Length > 7 && ln.Substring(0, 7) == "Keyword" && ln.Substring(ln.Length - 1, 1) == ":")
                {
                    if (ln.Substring(ln.Length - 5) == "desc:")
                    {
                        pos = POSITIONS.IN_DESC;
                    }
                    else
                    {
                        pos = POSITIONS.IN_KEYWORD;
                    }
                }
                else if (pos == POSITIONS.IN_DESC && ln.Length >= 3) //If we have DB followed by a quote
                {
                    KeywordDescription kd = new KeywordDescription();

                    string sv = ln.Substring(0, 3);
                    if (sv == "dw ")
                    {
                        string desc = ln.Substring(3).Trim();
                        kd.type = KEYWORDTYPE.FUNCTION;
                        kd.value = desc;
                        kd.value2 = "Function description";
                        kd.comment = comment;
                    }
                    else if (sv == "db ")
                    {
                        var values = ln.Substring(3).Trim().Split(',');
                        if (values.Length == 2)
                        {
                            kd.type = KEYWORDTYPE.KEYWORD;
                            kd.value = values[0].Trim();
                            kd.value2 = values[1].Trim();
                            kd.comment = comment;
                        } else
                        {
                            kd.type = KEYWORDTYPE.OTHER;
                            kd.value = "Error";
                            kd.value2 = "Error";
                            kd.comment = ln;
                        }
                    } else
                    {
                        kd.type = KEYWORDTYPE.OTHER;
                        kd.value = "Error2";
                        kd.value2 = "Error2";
                        kd.comment = ln;

                    }


                    description.Add(kd);
                } else
                {
                    Console.WriteLine($"Dont know : ({ln})");
                }

            }


            Console.WriteLine($"NumKw: {keywords.Count} NumDesc:{description.Count}");
            for (int i = 0; i < keywords.Count; i++)
            {
                writer.WriteLine($"{keywords[i].ToString()}, {description[i].ToString()}");
                Console.WriteLine($"{keywords[i].ToString()}, {description[i].ToString()}");
            }

            writer.Close();
            reader.Close();
        }

        private void btnProcess_Click_1(object sender, EventArgs e)
        {
            string csvFile = "C:\\a16\\ALL.csv";
            List<string> existing = new List<string>();
            int[] alphaLengths= new int[1] { 0 };
            int nRecords = 0;
            int stage = 0;
            int curLen = 0;
            char curLetter = (char)96;    //a is 97
            StreamWriter writer = new StreamWriter("C:\\a16\\Tools\\CPU16.out");
            StreamReader reader = new StreamReader(csvFile);


            string output1 = "";
            string output2 = "";
            string output3 = "";
            string final = "";
            while (!reader.EndOfStream)
            {
                string ln = reader.ReadLine();
                var items = ln.Split(',');

                UInt32 crc = Crc32.Calc(items[0]);
                string crc32s = crc.ToString("x").PadLeft(8, '0');
                string lowHalfCrc = crc32s.Substring(4);
                string highHalfCrc = crc32s.Substring(0,4);
                int len = items[0].Trim().Length;

                if (len != curLen)
                {

                    string outputPre = $"EVEN 2\r\n\tDB 0\r\nKeyword{len}:";
                    for (int i=0;i<26; i++)
                    {
                        outputPre += String.Format("%03d, ", alphaLengths[i]);                        
                    }
                    outputPre = outputPre.Substring(0, outputPre.Length - 1);

                    final += outputPre + "\r\n\r\n"  + output1 + "\r\n\r\n" + output2;

                    curLetter = (char)96;    //a is 97

                    alphaLengths = new int[26] {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
                    nRecords = 0;
                    curLen = len;
                    output2 = $"Keyword{len}High:";

                }

                while (curLetter != items[0].Trim().Substring(0, 1).ToCharArray()[0])
                {
                    int pos = curLetter - 97;
                    alphaLengths[pos] = nRecords;
                    output1 += $"Keyword{len}{curLetter}:";
                    curLetter += (char)1;
                }

                Console.WriteLine($"\tDW\t\t{lowHalfCrc}\t;{items[0]} low");
                output2 += $"\tDW\t\t{highHalfCrc}\t;{items[0]} high";
                if (items.Length > 2 && items[1] == "FUNCTION")
                {
                    output3 += $"\tDW\t\t({items[2]})\t;";
                } else if (items.Length > 3)
                {
                    output3 += $"\tDB\t\t{items[2]}, {items[3]}\t;";
                }
            }
        }
    }
}
